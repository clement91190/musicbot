from hf import hf_optimizer, SequenceDataset
from hf_examples import simple_RNN

def test_RNN():
    p, inputs, s, costs, h, ha = simple_RNN(100)
