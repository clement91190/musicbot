#from std.basic import load, save, show, show_seq, gsave, print_aligned, sigmoid, Rsigmoid, Dsigmoid, stochastic, monomial, id, print_seq, gload, fload, gsave, aux, aux2
                  
#from pylab import figure
#from weight_decay import l_p, dl_p
#from scipy.io import loadmat, savemat 


